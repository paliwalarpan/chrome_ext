# Download Expiry — Chrome Extension

Auto-cleanup your Downloads folder by setting expiry timers on downloaded files.

## Installation

1. Open Chrome and go to `chrome://extensions/`
2. Enable **Developer mode** (toggle in top-right corner)
3. Click **Load unpacked**
4. Select the `download-expiry-extension` folder
5. The extension icon (clock) will appear in your toolbar

## How It Works

- **Auto-tracking**: Every new browser download is automatically tracked with a default expiry (7 days).
- **Progress bar**: Each file shows a visual countdown — green → yellow → red as expiry approaches.
- **Notifications**: Get a heads-up before files are deleted (configurable).
- **Per-file control**: Change expiry, pause the timer, delete immediately, or keep forever.
- **File cleanup**: When a file expires, it's deleted from disk via `chrome.downloads.removeFile()`.

## Popup Features

| Tab     | Shows                                      |
|---------|---------------------------------------------|
| Active  | Files with running expiry timers            |
| Paused  | Files where you've paused the countdown     |
| Deleted | History of files that were auto-cleaned     |

### Per-file actions:
- **Dropdown**: Change expiry to 1d, 3d, 7d, 14d, 30d, or 90d
- **Pause/Resume**: Freeze or restart the expiry countdown
- **Delete**: Immediately delete the file from disk
- **Keep**: Remove the file from tracking entirely (keeps file forever)

## Settings

Access via the gear icon in the popup, or right-click the extension → Options.

| Setting              | Default | Description                              |
|----------------------|---------|------------------------------------------|
| Default expiry       | 7 days  | Applied to all new downloads             |
| Auto-track           | On      | Automatically track new downloads        |
| Notify before delete | On      | Desktop notification before expiry       |
| Notify minutes       | 30      | How far in advance to notify             |
| Ignore extensions    | (none)  | Skip tracking for specific file types    |

## Architecture

```
manifest.json        — Extension config (Manifest V3)
background.js        — Service worker: tracks downloads, manages alarms, handles deletion
popup.html/css/js    — Popup UI: lists downloads, controls expiry
options.html         — Full-page settings
icons/               — Extension icons (16, 48, 128px)
```

## Permissions Used

| Permission      | Why                                              |
|-----------------|--------------------------------------------------|
| `downloads`     | Track and delete downloaded files                |
| `downloads.open`| Access download metadata                         |
| `storage`       | Persist tracked downloads and settings           |
| `alarms`        | Schedule expiry and notification timers          |
| `notifications` | Warn before auto-deleting files                  |

## Limitations

- Only tracks downloads made through Chrome (not other apps)
- Cannot delete files if Chrome is closed when expiry hits (catches up on next launch)
- `chrome.downloads.removeFile()` only works for files Chrome downloaded
