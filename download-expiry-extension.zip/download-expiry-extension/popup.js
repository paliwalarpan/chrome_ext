// ============================================================
// Download Expiry — Popup Script
// ============================================================

let currentTab = 'active';
let downloads = {};
let settings = {};

// ---- Init ----

document.addEventListener('DOMContentLoaded', async () => {
  downloads = await sendMessage({ action: 'getDownloads' });
  settings = await sendMessage({ action: 'getSettings' });

  renderStats();
  renderList();
  bindTabs();
  bindSettings();

  // Refresh every 10s
  setInterval(async () => {
    downloads = await sendMessage({ action: 'getDownloads' });
    renderStats();
    renderList();
  }, 10000);
});

function sendMessage(msg) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(msg, resolve);
  });
}

// ---- Stats ----

function renderStats() {
  const entries = Object.values(downloads);
  const active = entries.filter(d => !d.deleted && !d.paused);
  const expiringSoon = active.filter(d => {
    const hoursLeft = (d.expiresAt - Date.now()) / (1000 * 60 * 60);
    return hoursLeft <= 24 && hoursLeft > 0;
  });
  const deleted = entries.filter(d => d.deleted);

  document.getElementById('statActive').textContent = active.length;
  document.getElementById('statExpiring').textContent = expiringSoon.length;
  document.getElementById('statDeleted').textContent = deleted.length;
}

// ---- Tabs ----

function bindTabs() {
  document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      currentTab = tab.dataset.tab;
      renderList();
    });
  });
}

// ---- Render list ----

function renderList() {
  const list = document.getElementById('downloadList');
  const entries = Object.values(downloads)
    .filter(d => {
      if (currentTab === 'active') return !d.deleted && !d.paused;
      if (currentTab === 'paused') return !d.deleted && d.paused;
      if (currentTab === 'deleted') return d.deleted;
      return false;
    })
    .sort((a, b) => (a.expiresAt || 0) - (b.expiresAt || 0));

  if (entries.length === 0) {
    list.innerHTML = `
      <div class="empty-state">
        <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" opacity="0.4">
          <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>
        </svg>
        <p>No ${currentTab} downloads.</p>
      </div>
    `;
    return;
  }

  list.innerHTML = entries.map(entry => buildCard(entry)).join('');
  bindCardActions();
}

function buildCard(entry) {
  const ext = entry.displayName.split('.').pop().toLowerCase();
  const typeClass = getTypeClass(ext);
  const size = formatSize(entry.fileSize);
  const now = Date.now();

  let progressHtml = '';
  let stateClass = '';

  if (entry.deleted) {
    stateClass = 'is-deleted';
  } else if (entry.paused) {
    stateClass = 'is-paused';
  } else {
    const total = entry.expiresAt - entry.startedAt;
    const elapsed = now - entry.startedAt;
    const pct = Math.max(0, Math.min(100, 100 - (elapsed / total) * 100));
    const timeLeft = formatTimeLeft(entry.expiresAt - now);
    const severity = pct > 50 ? 'safe' : pct > 20 ? 'warning' : 'danger';

    progressHtml = `
      <div class="dl-progress-wrap">
        <div class="dl-progress-bar">
          <div class="dl-progress-fill ${severity}" style="width: ${pct}%"></div>
        </div>
        <span class="dl-time-left">${timeLeft}</span>
      </div>
    `;
  }

  const expiryOptions = [1, 3, 7, 14, 30, 90].map(d =>
    `<option value="${d}" ${entry.expiryDays === d ? 'selected' : ''}>${d}d</option>`
  ).join('');

  let actionsHtml = '';
  if (entry.deleted) {
    actionsHtml = `<span style="font-size:11px; color: var(--text-muted);">Deleted ${formatTimeAgo(entry.deletedAt)}</span>`;
  } else if (entry.paused) {
    actionsHtml = `
      <button class="btn-sm success" data-action="togglePause" data-id="${entry.id}">Resume</button>
      <button class="btn-sm danger" data-action="deleteNow" data-id="${entry.id}">Delete</button>
      <button class="btn-sm" data-action="keepForever" data-id="${entry.id}">Keep Forever</button>
    `;
  } else {
    actionsHtml = `
      <select class="dl-expiry-select" data-action="updateExpiry" data-id="${entry.id}">${expiryOptions}</select>
      <button class="btn-sm" data-action="togglePause" data-id="${entry.id}">Pause</button>
      <button class="btn-sm danger" data-action="deleteNow" data-id="${entry.id}">Delete</button>
      <button class="btn-sm" data-action="keepForever" data-id="${entry.id}">Keep</button>
    `;
  }

  return `
    <div class="dl-card ${stateClass}">
      <div class="dl-card-top">
        <div class="dl-icon ${typeClass}">${ext.substring(0, 4)}</div>
        <div class="dl-info">
          <div class="dl-name" title="${entry.displayName}">${entry.displayName}</div>
          <div class="dl-meta">
            <span>${size}</span>
            <span class="sep">·</span>
            <span>${ext.toUpperCase()}</span>
          </div>
        </div>
      </div>
      ${progressHtml}
      <div class="dl-actions">${actionsHtml}</div>
    </div>
  `;
}

function bindCardActions() {
  // Buttons
  document.querySelectorAll('[data-action]').forEach(el => {
    if (el.tagName === 'SELECT') {
      el.addEventListener('change', async () => {
        const id = parseInt(el.dataset.id);
        const days = parseInt(el.value);
        await sendMessage({ action: 'updateExpiry', id, days });
        downloads = await sendMessage({ action: 'getDownloads' });
        renderStats();
        renderList();
      });
    } else {
      el.addEventListener('click', async () => {
        const action = el.dataset.action;
        const id = parseInt(el.dataset.id);
        await sendMessage({ action, id });
        downloads = await sendMessage({ action: 'getDownloads' });
        renderStats();
        renderList();
      });
    }
  });
}

// ---- Settings ----

function bindSettings() {
  document.getElementById('btnSettings').addEventListener('click', () => {
    populateSettings();
    document.getElementById('settingsPanel').classList.remove('hidden');
  });

  document.getElementById('btnCancelSettings').addEventListener('click', () => {
    document.getElementById('settingsPanel').classList.add('hidden');
  });

  document.getElementById('btnSaveSettings').addEventListener('click', async () => {
    const newSettings = {
      defaultExpiry: parseInt(document.getElementById('setDefaultExpiry').value) || 7,
      autoTrack: document.getElementById('setAutoTrack').checked,
      notifyBeforeDelete: document.getElementById('setNotify').checked,
      notifyMinutesBefore: parseInt(document.getElementById('setNotifyMinutes').value) || 30,
      ignoredExtensions: document.getElementById('setIgnoredExt').value
        .split(',')
        .map(s => s.trim().toLowerCase())
        .filter(Boolean),
      ignoredSizeAbove: 0,
    };
    await sendMessage({ action: 'saveSettings', settings: newSettings });
    settings = newSettings;
    document.getElementById('settingsPanel').classList.add('hidden');
  });
}

function populateSettings() {
  document.getElementById('setDefaultExpiry').value = settings.defaultExpiry || 7;
  document.getElementById('setAutoTrack').checked = settings.autoTrack !== false;
  document.getElementById('setNotify').checked = settings.notifyBeforeDelete !== false;
  document.getElementById('setNotifyMinutes').value = settings.notifyMinutesBefore || 30;
  document.getElementById('setIgnoredExt').value = (settings.ignoredExtensions || []).join(', ');
}

// ---- Helpers ----

function getTypeClass(ext) {
  const map = {
    image: ['png', 'jpg', 'jpeg', 'gif', 'webp', 'svg', 'bmp', 'ico', 'tiff'],
    video: ['mp4', 'mkv', 'avi', 'mov', 'webm', 'flv', 'wmv'],
    audio: ['mp3', 'wav', 'flac', 'ogg', 'aac', 'm4a', 'wma'],
    archive: ['zip', 'rar', '7z', 'tar', 'gz', 'bz2', 'xz'],
    document: ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'txt', 'csv', 'rtf'],
    code: ['js', 'ts', 'py', 'html', 'css', 'json', 'xml', 'yaml', 'yml', 'sh', 'rb', 'go', 'rs'],
  };
  for (const [type, exts] of Object.entries(map)) {
    if (exts.includes(ext)) return `type-${type}`;
  }
  return 'type-other';
}

function formatSize(bytes) {
  if (!bytes || bytes === 0) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB'];
  let i = 0;
  let size = bytes;
  while (size >= 1024 && i < units.length - 1) {
    size /= 1024;
    i++;
  }
  return `${size.toFixed(i > 0 ? 1 : 0)} ${units[i]}`;
}

function formatTimeLeft(ms) {
  if (ms <= 0) return 'Expired';
  const minutes = Math.floor(ms / 60000);
  if (minutes < 60) return `${minutes}m left`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ${minutes % 60}m`;
  const days = Math.floor(hours / 24);
  return `${days}d ${hours % 24}h`;
}

function formatTimeAgo(ts) {
  if (!ts) return '';
  const ms = Date.now() - ts;
  const minutes = Math.floor(ms / 60000);
  if (minutes < 1) return 'just now';
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  return `${days}d ago`;
}
