// ============================================================
// Download Expiry — Background Service Worker
// ============================================================

const DEFAULT_SETTINGS = {
  defaultExpiry: 7,          // days
  autoTrack: true,           // auto-track new downloads
  notifyBeforeDelete: true,  // notify before deleting
  notifyMinutesBefore: 30,   // minutes before expiry to notify
  ignoredExtensions: [],     // file extensions to ignore
  ignoredSizeAbove: 0,       // ignore files above this size (MB), 0 = no limit
};

// ---- Storage helpers ----

async function getSettings() {
  const result = await chrome.storage.local.get('settings');
  return { ...DEFAULT_SETTINGS, ...(result.settings || {}) };
}

async function getTrackedDownloads() {
  const result = await chrome.storage.local.get('trackedDownloads');
  return result.trackedDownloads || {};
}

async function saveTrackedDownloads(downloads) {
  await chrome.storage.local.set({ trackedDownloads: downloads });
}

// ---- Download tracking ----

chrome.downloads.onCreated.addListener(async (downloadItem) => {
  const settings = await getSettings();
  if (!settings.autoTrack) return;

  // We wait for completion, so just mark it as pending
  // The actual tracking happens in onChanged when state = 'complete'
});

chrome.downloads.onChanged.addListener(async (delta) => {
  if (!delta.state || delta.state.current !== 'complete') return;

  const settings = await getSettings();
  if (!settings.autoTrack) return;

  // Fetch the full download item
  const [item] = await chrome.downloads.search({ id: delta.id });
  if (!item || !item.filename) return;

  // Check ignored extensions
  const ext = item.filename.split('.').pop().toLowerCase();
  if (settings.ignoredExtensions.includes(ext)) return;

  // Check ignored size
  if (settings.ignoredSizeAbove > 0 && item.fileSize > settings.ignoredSizeAbove * 1024 * 1024) return;

  const now = Date.now();
  const expiryMs = settings.defaultExpiry * 24 * 60 * 60 * 1000;
  const expiresAt = now + expiryMs;

  const tracked = await getTrackedDownloads();
  tracked[item.id] = {
    id: item.id,
    filename: item.filename,
    displayName: item.filename.split(/[/\\]/).pop(),
    url: item.url,
    fileSize: item.fileSize,
    mime: item.mime,
    startedAt: now,
    expiresAt: expiresAt,
    expiryDays: settings.defaultExpiry,
    paused: false,
    deleted: false,
  };

  await saveTrackedDownloads(tracked);

  // Set alarm for cleanup
  await chrome.alarms.create(`expire_${item.id}`, { when: expiresAt });

  // Set alarm for pre-delete notification
  if (settings.notifyBeforeDelete) {
    const notifyAt = expiresAt - settings.notifyMinutesBefore * 60 * 1000;
    if (notifyAt > now) {
      await chrome.alarms.create(`notify_${item.id}`, { when: notifyAt });
    }
  }

  // Update badge
  updateBadge();
});

// ---- Alarm handler ----

chrome.alarms.onAlarm.addListener(async (alarm) => {
  const tracked = await getTrackedDownloads();

  if (alarm.name.startsWith('notify_')) {
    const id = parseInt(alarm.name.replace('notify_', ''));
    const entry = tracked[id];
    if (entry && !entry.paused && !entry.deleted) {
      chrome.notifications.create(`expiry_warn_${id}`, {
        type: 'basic',
        iconUrl: 'icons/icon128.png',
        title: 'Download Expiring Soon',
        message: `"${entry.displayName}" will be deleted in ${(await getSettings()).notifyMinutesBefore} minutes.`,
        buttons: [{ title: 'Keep File' }, { title: 'Delete Now' }],
        priority: 2,
      });
    }
  }

  if (alarm.name.startsWith('expire_')) {
    const id = parseInt(alarm.name.replace('expire_', ''));
    const entry = tracked[id];
    if (entry && !entry.paused && !entry.deleted) {
      await deleteDownload(id);
    }
  }

  // Periodic sweep
  if (alarm.name === 'periodic_sweep') {
    await sweepExpired();
  }
});

// ---- Notification button handler ----

chrome.notifications.onButtonClicked.addListener(async (notificationId, buttonIndex) => {
  if (!notificationId.startsWith('expiry_warn_')) return;
  const id = parseInt(notificationId.replace('expiry_warn_', ''));

  if (buttonIndex === 0) {
    // Keep file — pause expiry
    const tracked = await getTrackedDownloads();
    if (tracked[id]) {
      tracked[id].paused = true;
      await saveTrackedDownloads(tracked);
      await chrome.alarms.clear(`expire_${id}`);
    }
  } else if (buttonIndex === 1) {
    // Delete now
    await deleteDownload(id);
  }

  chrome.notifications.clear(notificationId);
});

// ---- Delete logic ----

async function deleteDownload(id) {
  const tracked = await getTrackedDownloads();
  const entry = tracked[id];
  if (!entry || entry.deleted) return;

  try {
    await chrome.downloads.removeFile(id);
    tracked[id].deleted = true;
    tracked[id].deletedAt = Date.now();
    await saveTrackedDownloads(tracked);
  } catch (err) {
    console.warn(`Could not delete file for download ${id}:`, err);
    // File might already be gone — mark it anyway
    tracked[id].deleted = true;
    tracked[id].deletedAt = Date.now();
    tracked[id].deleteError = err.message;
    await saveTrackedDownloads(tracked);
  }

  // Clean up alarms
  await chrome.alarms.clear(`expire_${id}`);
  await chrome.alarms.clear(`notify_${id}`);

  updateBadge();
}

async function sweepExpired() {
  const tracked = await getTrackedDownloads();
  const now = Date.now();
  let changed = false;

  for (const [id, entry] of Object.entries(tracked)) {
    if (!entry.deleted && !entry.paused && entry.expiresAt <= now) {
      await deleteDownload(parseInt(id));
      changed = true;
    }
  }

  if (changed) updateBadge();
}

// ---- Badge ----

async function updateBadge() {
  const tracked = await getTrackedDownloads();
  const activeCount = Object.values(tracked).filter(d => !d.deleted && !d.paused).length;
  const text = activeCount > 0 ? String(activeCount) : '';
  chrome.action.setBadgeText({ text });
  chrome.action.setBadgeBackgroundColor({ color: '#e74c3c' });
}

// ---- Periodic sweep on startup ----

chrome.runtime.onStartup.addListener(() => {
  chrome.alarms.create('periodic_sweep', { periodInMinutes: 60 });
  sweepExpired();
  updateBadge();
});

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create('periodic_sweep', { periodInMinutes: 60 });
  updateBadge();
});

// ---- Message handler for popup communication ----

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'getDownloads') {
    getTrackedDownloads().then(sendResponse);
    return true;
  }

  if (message.action === 'getSettings') {
    getSettings().then(sendResponse);
    return true;
  }

  if (message.action === 'saveSettings') {
    chrome.storage.local.set({ settings: message.settings }).then(() => sendResponse({ ok: true }));
    return true;
  }

  if (message.action === 'deleteNow') {
    deleteDownload(message.id).then(() => sendResponse({ ok: true }));
    return true;
  }

  if (message.action === 'togglePause') {
    (async () => {
      const tracked = await getTrackedDownloads();
      const entry = tracked[message.id];
      if (entry) {
        entry.paused = !entry.paused;
        if (entry.paused) {
          await chrome.alarms.clear(`expire_${message.id}`);
          await chrome.alarms.clear(`notify_${message.id}`);
        } else {
          // Re-arm alarm with remaining time (at least 1 minute)
          const remaining = Math.max(entry.expiresAt - Date.now(), 60000);
          entry.expiresAt = Date.now() + remaining;
          await chrome.alarms.create(`expire_${message.id}`, { when: entry.expiresAt });
        }
        await saveTrackedDownloads(tracked);
        updateBadge();
      }
      sendResponse({ ok: true });
    })();
    return true;
  }

  if (message.action === 'updateExpiry') {
    (async () => {
      const tracked = await getTrackedDownloads();
      const entry = tracked[message.id];
      if (entry) {
        const newExpiryMs = message.days * 24 * 60 * 60 * 1000;
        entry.expiresAt = entry.startedAt + newExpiryMs;
        entry.expiryDays = message.days;
        if (!entry.paused) {
          await chrome.alarms.clear(`expire_${message.id}`);
          await chrome.alarms.create(`expire_${message.id}`, { when: entry.expiresAt });
        }
        await saveTrackedDownloads(tracked);
      }
      sendResponse({ ok: true });
    })();
    return true;
  }

  if (message.action === 'clearDeleted') {
    (async () => {
      const tracked = await getTrackedDownloads();
      const filtered = {};
      for (const [id, entry] of Object.entries(tracked)) {
        if (!entry.deleted) filtered[id] = entry;
      }
      await saveTrackedDownloads(filtered);
      sendResponse({ ok: true });
    })();
    return true;
  }

  if (message.action === 'keepForever') {
    (async () => {
      const tracked = await getTrackedDownloads();
      delete tracked[message.id];
      await saveTrackedDownloads(tracked);
      await chrome.alarms.clear(`expire_${message.id}`);
      await chrome.alarms.clear(`notify_${message.id}`);
      updateBadge();
      sendResponse({ ok: true });
    })();
    return true;
  }
});
